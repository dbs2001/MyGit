#include <cstdlib>
#include <iostream>
#include <cstring>
#include "Stringdbs.h"
using namespace std;

int main()
{
    // char* ptr;
    // char a = '1';
    // ptr = &a;
    // StringBuffer sb(ptr,1); 
    // StringBuffer tb(sb);  
    // sb.length();
    // sb.reserve(1);
    // sb.append('2'); 

    char *c = "Danish\0";
    String ss1(c,6);

    ss1.printString();

    ss1.append('H');
    ss1.printString();  
    cout << ss1.length();  
    cout << endl << endl << endl;
    
    String ss2(ss1);
    ss2.printString();
    ss2.append('M');
    ss2.printString();
    cout << ss2.length();

    cout << endl << endl << endl;
    // ss1->printString();
    // ss1->append('H');
    // ss1->printString();
    // cout<<"ss1 length = "<<ss1->length()<<endl;
    
    // StringBuffer* ss2 = new StringBuffer(*ss1);
    // ss2->printString();
    // ss2->append('M');
    // ss2->printString();
    // cout<<"ss2 length = "<<ss2->length()<<endl;
    // cout << endl << endl << endl;
    
    // ss1->printString();
    // cout<<"ss1 length = "<<ss1->length()<<endl;
    // ss2->printString();
    // cout<<"ss2 length = "<<ss2->length()<<endl;

    // delete ss1;
    // delete ss2;
    ////cout<<"character at 5 in ss1 is "<< ss1->charAt(5) << endl;
    //ss1->append('x');
    


}