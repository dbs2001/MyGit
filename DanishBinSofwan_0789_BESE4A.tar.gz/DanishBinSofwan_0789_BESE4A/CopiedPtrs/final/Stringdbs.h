#ifndef STRING_H
#define STRING_H

#include "StringBufferdbs.h"
#include <memory>
#include <iostream>

using namespace std;
class String
{
    public:
        StringBuffer *forwarder;

    String(){
        this->forwarder = new StringBuffer();
    };
    ~String(){
        cout << "String destructor called" << endl;
        delete this->forwarder;
    };
    String(String &ss1){
        this->forwarder = new StringBuffer(*ss1.forwarder);
    };
    String(char* c,int length){
        this->forwarder = new StringBuffer(c, length);
    };
    void append(char c){
        auto_ptr<StringBuffer> newdata(new StringBuffer);
        newdata.get()->reserve(this->forwarder->length() + 1);
        //cout << endl << endl << "there ->>"<< length << endl;
        newdata.get()->smartCopy(this->forwarder);
        this->forwarder = newdata.release();
        this->forwarder->append(c);
    };
    int length() const{
        return this->forwarder->length();
    };
    char charAt(int i) const{
        if(this->forwarder != NULL)
        {
            return this->forwarder->charAt(i);
        }
        else
        {
            cout << "Pointer contains NULL, looks like a case of Ownership Transfer." << endl;
        }
    };
    void printString(){
        this->forwarder->printString();
    };
    

};
#endif  /* STRING_H */