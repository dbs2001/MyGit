#ifndef STRINGBUFFER_H
#define STRINGBUFFER_H

#include <memory>
#include <iostream>

using namespace std;


 class StringBuffer{

    public :
        StringBuffer(){
            this->_strbuf = 0;
            this->_length = 0;
        };
        ~StringBuffer(){
              cout << "*** deleting the allocated buffer" << endl;
              delete[] this->_strbuf;
        };                

        StringBuffer(StringBuffer& newString){
              
              this->_strbuf = new char[newString.length()];
              this->_length = newString.length();
              this->smartCopy(newString._strbuf, _length);
        };              

        StringBuffer(char* newString,int length){
            _length = length;
            delete[] _strbuf;
            _strbuf = new char[length];
            _strbuf = newString;
        };
        void smartCopy(StringBuffer* newString) {
            
            int shorterLength = 0;
            (this->_length < newString->_length) ? shorterLength = this->_length : shorterLength = newString->_length;
            int it = 0;
    
            while (it < shorterLength) {
                _strbuf[it] = *(newString->_strbuf)++;
                it++;
            }
        }
        void smartCopy(char* newString, int length) {
            cout << "*** Deep Copying" << endl;
            this->_length = length;
            int it = 0;
            
            while (it < length) {
                _strbuf[it] = *newString++;
                it++;
            }
          }
        char charAt(int index) const{
            if (index < _length) {
                return _strbuf[index];
            } else {
                cout << "Index out of bound " << endl;
            }
        };   

        int length() const{
            return this->_length;
        };                            
        void reserve(int n){
            
            if (_length < n) {
                int newlength = n; 
                char* newbuf = new char[newlength];
                this->revSmartCopy(newbuf);
                
                delete[] _strbuf;
                _strbuf = newbuf;
                _length = newlength;
            }
        }; 
        void revSmartCopy(char* newString) {
            int it = 0;
            while (it < _length) {
                newString[it] = _strbuf[it];
                it++;
            }
        }                      
        void printString()
        {
            cout << "printing String : "<< _strbuf << endl;
        }
        void append(char c){
           this->_strbuf[_length-1] = c;
        };                          
    
    private:

        char* _strbuf;                                   //buffer to store the original string
        int _length;                                       //length of the string
};
#endif  /* STRINGBUFFER_H */