#ifndef STRING_H
#define STRING_H

#include "StringBufferdbs.h"
#include <memory>
#include <iostream>

using namespace std;
class String
{
    public:
        StringBuffer *forwarder;
	StringBuffer *Next;
	

    String(){
        this->forwarder = new StringBuffer();
    };
    ~String(){
        cout << "String destructor called" << endl;

        if (--this->forwarder->_refcount < 1) {
	delete this->Next;            
	delete this->forwarder;
		
    }
        
    };
    String(String &ss1){
        this->forwarder = new StringBuffer(*ss1.forwarder);
        this->forwarder = ss1.forwarder;
        ++this->forwarder->_refcount;
	this->Next = ss1.forwarder;
    };
    String(char* c,int length){
        this->forwarder = new StringBuffer(c, length);

        this->forwarder->_refcount = 1;
    };
    void append(char c){
    //     auto_ptr<StringBuffer> newdata(new StringBuffer);
    //     newdata.get()->reserve(this->forwarder->length() + 1);
    //     //cout << endl << endl << "there ->>"<< length << endl;
    //     newdata.get()->smartCopy(this->forwarder);
    //     this->forwarder = newdata.release();
    //     this->forwarder->append(c);

    //     //    char* tempbuf = new char[this->_str->length()+1];
    // //    this->_str->revSmartCopy(tempbuf);
    if (this->forwarder->_refcount > 1) {
        auto_ptr<StringBuffer> newdata(new StringBuffer);
        newdata.get()->reserve(this->forwarder->length() + 1);
        newdata.get()->smartCopy(this->forwarder);
        --this->forwarder->_refcount;
        this->forwarder = newdata.release();
    } else {
        this->forwarder->reserve(this->forwarder->length() + 1);
    }
        this->forwarder->append(c);
    };

    int length() const{
        if(this->forwarder != NULL)
        {
            return this->forwarder->length();
        }
        
    };
    char charAt(int i) const{
        if(this->forwarder != NULL)
        {
            return this->forwarder->charAt(i);
        }
        
    };
    void printString(){
        if(this->forwarder != NULL)
        {
            this->forwarder->printString();
        }
        else
        {
            cout << "Pointer contains NULL, looks like a case of Ownership Transfer." << endl;
        }
    };
    

};
#endif  /* STRING_H */
