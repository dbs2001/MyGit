#include <cstdlib>
#include <iostream>
#include <cstring>
#include "Stringdbs.h"
using namespace std;

int main()
{
    
    String ss1("Danish",6);
    ss1.printString();
    ss1.append('1');
    ss1.printString();  
    cout << ss1.length() << endl;
    cout << ss1.charAt(3) << endl;  
    cout << endl << endl << endl;
    
    String ss2(ss1);
    ss2.printString();
    ss2.append('2');
    ss2.printString();
    cout << ss2.length() << endl;
    cout << ss2.charAt(3) << endl;
    cout << endl << endl << endl;

    ss1.printString();
}