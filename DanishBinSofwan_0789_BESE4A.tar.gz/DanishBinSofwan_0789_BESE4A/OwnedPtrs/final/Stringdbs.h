#ifndef STRING_H
#define STRING_H

#include "StringBufferdbs.h"
#include <memory>
#include <iostream>

using namespace std;
class String
{
    public:
        StringBuffer *forwarder;

    String(){
        this->forwarder = new StringBuffer();
    };
    ~String(){
        cout << "String destructor called" << endl;
        delete this->forwarder;
    };
    String(String &ss1){
        this->forwarder = new StringBuffer(*ss1.forwarder);
        ss1.forwarder = NULL;
    };
    String(char* c,int length){
        this->forwarder = new StringBuffer(c, length);
    };
    void append(char c){
        auto_ptr<StringBuffer> newdata(new StringBuffer);
        newdata.get()->reserve(this->forwarder->length() + 1);
        //cout << endl << endl << "there ->>"<< length << endl;
        newdata.get()->smartCopy(this->forwarder);
        this->forwarder = newdata.release();
        this->forwarder->append(c);
    };
    int length() const{
        if(this->forwarder != NULL)
        {
            return this->forwarder->length();
        }
        else
        {
            cout << "Pointer contains NULL, looks like a case of Ownership Transfer." << endl;
            return -1;
        }
    };
    char charAt(int i) const{
        if(this->forwarder != NULL)
        {
            return this->forwarder->charAt(i);
        }
        else
        {
            cout << "Pointer contains NULL, looks like a case of Ownership Transfer." << endl;
        }
    };
    void printString(){
        if(this->forwarder != NULL)
        {
            this->forwarder->printString();
        }
        else
        {
            cout << "Pointer contains NULL, looks like a case of Ownership Transfer." << endl;
        }
    };
    

};
#endif  /* STRING_H */